
import json
import logging
import os
import threading
from telegram import Update
from telegram.ext import Updater, CommandHandler, CallbackContext

# === CONFIG ===
TOKEN = "YOUR_BOT_TOKEN_HERE"
ADMIN_CHAT_ID = 7185830984
FILE_PATH = "secure_file.7z"  # Replace with the path to your .7z file
PASSWORD_FILE = "passwords.json"

# === LOGGING ===
logging.basicConfig(level=logging.INFO)

# === SESSION CACHE ===
logged_in_admins = set()
logged_in_users = set()

# === FILE STORAGE ===
def load_passwords():
    try:
        with open(PASSWORD_FILE, "r") as f:
            return json.load(f)
    except:
        return {"admins": ["admin123"], "users": ["user123"]}

def save_passwords(data):
    with open(PASSWORD_FILE, "w") as f:
        json.dump(data, f)

# === DELETE MESSAGE AFTER DELAY ===
def delete_after_delay(context: CallbackContext, chat_id: int, message_id: int, delay: int = 60):
    def delete_msg():
        try:
            context.bot.delete_message(chat_id=chat_id, message_id=message_id)
        except Exception as e:
            logging.warning(f"Failed to delete message: {e}")
    threading.Timer(delay, delete_msg).start()

# === /start ===
def start(update: Update, context: CallbackContext):
    chat_id = update.message.chat_id
    args = context.args
    passwords = load_passwords()

    if chat_id in logged_in_admins:
        update.message.reply_text("👑 You are already logged in as admin. Use /admin to manage passwords.")
        return
    if chat_id in logged_in_users:
        update.message.reply_text("✅ You are already logged in.")
        return

    if not args:
        update.message.reply_text("❌ Use like: /start yourpassword")
        return

    password = args[0]

    if password in passwords["admins"]:
        logged_in_admins.add(chat_id)
        update.message.reply_text("👑 *Admin Access Granted!*\nUse /admin to manage passwords.", parse_mode="Markdown")
    elif password in passwords["users"]:
        logged_in_users.add(chat_id)
        update.message.reply_text("✅ *User Access Granted!*\nSending your file...", parse_mode="Markdown")
        if os.path.exists(FILE_PATH):
            sent_msg = context.bot.send_document(chat_id=chat_id, document=open(FILE_PATH, "rb"))
            delete_after_delay(context, chat_id, sent_msg.message_id, delay=60)
        else:
            update.message.reply_text("⚠️ File not found.")
    else:
        update.message.reply_text("⛔ Invalid password.")

# === /admin ===
def admin(update: Update, context: CallbackContext):
    chat_id = update.message.chat_id
    if chat_id not in logged_in_admins:
        update.message.reply_text("🚫 You are not authorized to use this command.")
        return

    args = context.args
    passwords = load_passwords()

    if not args:
        update.message.reply_text("👨‍💼 *Admin Panel*\n\nCommands:\n/add [pw]\n/remove [pw]\n/replace [old] [new]\n/list", parse_mode="Markdown")
        return

    cmd = args[0].lower()

    if cmd == "add" and len(args) > 1:
        new_pw = args[1]
        if new_pw in passwords["users"]:
            update.message.reply_text("⚠️ Password already exists.")
        else:
            passwords["users"].append(new_pw)
            save_passwords(passwords)
            update.message.reply_text(f"✅ Password '{new_pw}' added.")

    elif cmd == "remove" and len(args) > 1:
        pw = args[1]
        if pw in passwords["users"]:
            passwords["users"].remove(pw)
            save_passwords(passwords)
            update.message.reply_text(f"🗑️ Password '{pw}' removed.")
        else:
            update.message.reply_text("❌ Password not found.")

    elif cmd == "replace" and len(args) > 2:
        old_pw, new_pw = args[1], args[2]
        if old_pw in passwords["users"]:
            passwords["users"].remove(old_pw)
            passwords["users"].append(new_pw)
            save_passwords(passwords)
            update.message.reply_text(f"✏️ Replaced '{old_pw}' with '{new_pw}'.")
        else:
            update.message.reply_text("❌ Old password not found.")

    elif cmd == "list":
        pw_list = passwords["users"]
        update.message.reply_text("📜 Passwords:\n" + "\n".join(pw_list) if pw_list else "📭 No passwords found.")

    else:
        update.message.reply_text("❌ Invalid admin command.")

# === /logout ===
def logout(update: Update, context: CallbackContext):
    chat_id = update.message.chat_id
    if chat_id in logged_in_admins:
        logged_in_admins.remove(chat_id)
        update.message.reply_text("🚪 Logged out as admin.")
    elif chat_id in logged_in_users:
        logged_in_users.remove(chat_id)
        update.message.reply_text("🚪 Logged out.")
    else:
        update.message.reply_text("❌ You are not logged in.")

# === MAIN ===
def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start, pass_args=True))
    dp.add_handler(CommandHandler("admin", admin, pass_args=True))
    dp.add_handler(CommandHandler("logout", logout))

    updater.start_polling()
    print("Bot is running...")
    updater.idle()

if __name__ == "__main__":
    main()
